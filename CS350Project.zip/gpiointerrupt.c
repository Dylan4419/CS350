/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
//Dylan Coulter
//Course: CS350
//Assignment: Project One
//Date: 08/16/2024

#include <stddef.h>
#include <stdint.h>

/****************************/
/*** Driver Header files ****/
/****************************/
#include <ti/drivers/GPIO.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/UART2.h>

/****************************/
/*** Driver configuration ***/
/****************************/
#include "ti_drivers_config.h"

/****************************/
/******* Definitions ********/
/****************************/

//Heat status, set point, and current temperature
//Seconds in snprintf
#define DISPLAY(x) UART2_write(uart, &output, x, NULL)
//periods set to 100, 200, 500, 1000
//number of task set to 3
#define timerPeriod 100
#define numTasks 3
#define checkButtonPeriod 200
#define checkTemperaturePeriod 500
#define updateHeatModeAndServerPeriod 1000

/****************************/
/****** Task Types **********/
/****************************/

typedef struct task {
    //tasks current state
    int currentState;
    //Tick rate of the tasks
    unsigned long tickPeriod;
    //Elapsed time since last tick
    unsigned long tickTime;
    int (*tickFunction)(int);
} task;

/****************************/
/****** Driver Handles ******/
/****************************/

//I2C Driver Handle
I2C_Handle i2c;
//Timer Driver Handle
Timer_Handle timer0;
//UART Driver Handle
UART2_Handle uart;


/****************************/
/***** Global Variables *****/
/****************************/

//UART Global Variables
char output[64];

//I2C Global Variables
static const struct
{
    uint8_t address;
    uint8_t resultReg;
    char *id;
}
sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

//Timer Global Variables
volatile unsigned char TimerFlag = 0;

//Thermostat Global Variables
//States for certain button presses
enum buttonStates {tempUp, tempDown, buttonInit} buttonState;
//States for the temperature sensor
enum tempStates {tempRead, tempInit};
//States for the red LED to indicate whether heat is on or off
enum ledStates {ledOff, ledOn, ledInit};
//Temperature will be set to 0 and will be updated by the sensor
int16_t ambientTemperature = 0;
//Thermostat set point is set to 20 degrees or 68 degrees fahrenheit
int16_t setPoint = 20;
//Time will be set to 0 seconds and will be updated by the timer
int seconds = 0;

/****************************/
/******** Call Backs ********/
/****************************/

//GPIO button call backs to either increase or decrease the set point on the thermostat
void gpioIncreaseTemperatureCallback(uint_least8_t index)
{
    buttonState = tempUp;
}

void gpioDecreaseTemperatureCallback(uint_least8_t index)
{
    buttonState = tempDown;
}

//Timer Call back
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}

/****************************/
/******* Initialization *****/
/****************************/

// *******Initialize UART2***/
//********PLEASE NOTE********/
//UART2 was used as it is the updated version of UART and UART was not an option
void initUART(void)
{
    UART2_Params uartParams;

    //Configure the driver
    UART2_Params_init(&uartParams);
    uartParams.readReturnMode = UART2_ReadReturnMode_FULL;
    uartParams.baudRate = 115200;

    //Open the driver
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL)
    {
        /* UART_open() failed */
        while (1);
    }
}

/******* Initialize I2C *******/
/******* PLEASE NOTE **********/
// Most Code in this section is from the LAB document

void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "));

    //Initialize the driver
    I2C_init();

    //Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    //Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"));
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"));

    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses.

    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;
    for (i=0; i<3; ++i)
    {
         i2cTransaction.targetAddress = sensors[i].address; // Previously called slaveAddress
         txBuffer[0] = sensors[i].resultReg;

         DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id));
         if (I2C_transfer(i2c, &i2cTransaction))
         {
             DISPLAY(snprintf(output, 64, "Found\n\r"));
             found = true;
             break;
         }
         DISPLAY(snprintf(output, 64, "No\n\r"));
    }

    if(found)
    {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.targetAddress)); // Previously slaveAddress
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"));
    }
}

/******** Initialize GPIO *******/

void initGPIO(void)
{
    //Initialize functions for the driver
    GPIO_init();


    //Configure the LED_0 and Button_0 pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    // LED will Start by being turned off
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    //Install the Button callback
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioIncreaseTemperatureCallback);

    // Enable the interrupts
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        // Configure BUTTON_1 pin
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        //Install the Button callback
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioDecreaseTemperatureCallback);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    buttonState = buttonInit;
}

/******* Initialize Timer *********/
/********** PLEASE NOTE **********/
// Most Code in this section is from the LAB document

void initTimer(void)
{
    Timer_Params params;

    //Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL)
    {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR)
    {
        /* Failed to start timer */
        while (1) {}
    }
}

/****************************/
/**** Adjust Temperature ****/
/****************************/

//Checks to see what button is pressed and whether to increase or decrease temperature
//Then the button will be reset

int adjustSetPointTemperature(int currentState)
{
    //Checks if desired temperature has been change
    //We also want to ensure the Temperature stays with in a range between 0 and 99 degrees Celsius
    switch (currentState)
    {
        case tempUp:
            if (setPoint < 99)
            {
                setPoint++;
            }
            buttonState = buttonInit;
            break;
        case tempDown:
            if (setPoint > 0)
            {
                setPoint--;
            }
            buttonState = buttonInit;
            break;
    }
    // After reading the button will be reset
    currentState = buttonState;

    return currentState;
}

//  readTemp //
//  Read in the current temperature from the sensor and return the reading

/****************************/
/***** Read Temperature *****/
/****************************/

/******PLEASE NOTE********/
// Code from the LAB guide is included in this section

int16_t readTemp(void)
{
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        * Extract degrees C from the received data;
        * see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]); temperature *= 0.0078125;
        /*
        * If the MSB is set '1', then we have a 2's complement * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status));
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"));
    }
    return temperature;
}

/****************************/
/**** Ambient Temperature ***/
/****************************/

int getAmbientTemperature(int currentState)
{
    switch (currentState)
    {
        case tempInit:
            currentState = tempRead;
            break;
        case tempRead:
            ambientTemperature = readTemp();
            break;
    }

    return currentState;
}

/****************************/
/********* Set Heat *********/
/****************************/

//Checks ambient temperature to the set temperature
//LED will be either on or off depending if the ambient temperature is lower of higher than the set temperature
//Red LED will be on if ambient temperature is lower than set temperature
//RED LED will be off if ambient temperature is higher than set temperature

int setHeatMode(int currentState)
{
    if (seconds != 0)
    {
        //If ambient temperature is lower than set temperature the red LED will turn of
        //This indicating heating
        if (ambientTemperature < setPoint)
        {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            currentState = ledOn;
        }
        //Else the ambient temperature is above the set temperature turning the red LED off
        //This indicates it is not heating
        else
        {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            currentState = ledOff;
        }

        DISPLAY(snprintf(output,
                             64,
                             "<%02d,%02d,%d,%04d>\n\r",
                             ambientTemperature,
                             setPoint,
                             currentState,
                             seconds));
    }

    seconds++;

    return currentState;
}

/****************************/
/********* Main Loop ********/
/****************************/
void *mainThread(void *arg0)
{
    //Create a list with tasks, there are a total of three tasks
    //Task 1:Verify the state of the button and update the temperature
    //Task 2:Check sensor for current temperature
    //Task 3:Update the current heat mode
    task tasks[numTasks] = {

               /******* Task 1 *******/
        {
            .currentState = buttonInit,
            .tickPeriod = checkButtonPeriod,
            .tickTime = checkButtonPeriod,
            .tickFunction = &adjustSetPointTemperature
        },
              /******** Task 2 ********/
        {
            .currentState = tempInit,
            .tickPeriod = checkTemperaturePeriod,
            .tickTime = checkTemperaturePeriod,
            .tickFunction = &getAmbientTemperature
        },
             /********* Task 3 *********/
        {
            .currentState = ledInit,
            .tickPeriod = updateHeatModeAndServerPeriod,
            .tickTime = updateHeatModeAndServerPeriod,
            .tickFunction = &setHeatMode
        }
    };

    /****************************/
    /**** Call Initialization ***/
    /******** Functions *********/
    /***** For The Drivers ******/
    /****************************/

    //UART must be initiated before I2C
    initUART();
    initI2C();
    initGPIO();
    initTimer();

    // Loop Forever
    while (1)
    {
        unsigned int i = 0;
        for (i = 0; i < numTasks; ++i)
        {
            if ( tasks[i].tickTime >= tasks[i].tickPeriod )
            {
                tasks[i].currentState = tasks[i].tickFunction(tasks[i].currentState);
                tasks[i].tickTime = 0;
             }
             tasks[i].tickTime += timerPeriod;
        }

        //wait for the timer period
        while(!TimerFlag){}

        // Time flag set to False
        TimerFlag = 0;
    }

    return (NULL);
}
